//************************************************
//*************** Reflection vector OBJECT ****************
//************************************************
function SymaVectorObject(_construction, _name, _L, _S) {
	
	L=_L;
	var simaPuntos=_construction.getAllObjectsFromType("point");
	Ref=[];
	ptos=[_S.getP1(),_S.getP2()];
	
	
	for (var i = 0, len = 2; i < len; i++) {
	  var ptoExistente=-1;
	  for (var j = 0, len2 = simaPuntos.length; j < len2; j++) {
		  
		  if (simaPuntos[j].isChild(L)&&simaPuntos[j].isChild(ptos[i])){ptoExistente=j}
		  
	  }
	  if (ptoExistente>-1){var ext=simaPuntos[ptoExistente]}
	  if (ptoExistente==-1) {var ext = new SymaPointObject(_construction, "_P", L, ptos[i]);_construction.add(ext);}
	  Ref.push(ext);
  }
	  
	ext1=Ref[0];
	
	
	ext2= Ref[1];
	
	// ext1.setFillStyle(2);
	// ext2.setFillStyle(2);
	$U.extend(this, new VectorObject(_construction, "_v", ext1, ext2)); // Herencia
  var L = _L;
  var S = _S;
  // MEAG start
  var Cn = _construction;
  // MEAG end
  // this.setParent(L, P);
  this.setParent(L, S, ext1, ext2);
 

  this.getCode = function() {
    return "vector";
  };


  this.isMoveable = function() {
    return false;
  };


  this.compute = function() {
    // L.reflect(S.getP1(), ext1);
	// L.reflect(P.getP2(), ext2);
	
    // MEAG start
    if (!Cn.getFrame().ifObject(this.getName())) {
      Cn.getFrame().getTextCons(this);
    }
    // MEAG end
  };
  // ext1.setParent(this);
  // ext2.setParent(this);

  this.getSource = function(src) {
    // if (this.execMacroSource(src)) return;
    src.geomWrite(false, this.getName(), "Reflection", L.getVarName(), S.getVarName());
  };

  // MEAG start
  this.getTextCons = function() {
    if (this.getParentLength()) {
      texto = "";
      texto = this.getName() + $L.object_syma_description_of + S.getVarName() + $L.object_syma_description_wrto + L.getVarName();
      parents = [S.getVarName(), L.getVarName()];
      return {
        "texto": texto,
        "parents": parents
      };
    }
  }
  // MEAG end

};
