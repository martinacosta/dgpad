/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function MoveableObject(_construction) {
    //    var Cn = _construction;
    //    this.startDragX = 0;
    //    this.startDragY = 0;
    //
    ////    Ne pas surcharger :
    //    this.startDrag = function(x, y) {
    //        this.dragTo = (Cn.is3D()) ? dragTo3D : dragToNormal;
    //        Cn.doOrder(this.getChildList());
    //        this.startDragX = x;
    //        this.startDragY = y;
    //    };
    //
    //
    //    this.isMoveable = function() {
    //        return true;
    //    };
    //    
    //
    //
    //    var dragTo3D = function(x, y) {
    //        this.dragObject(x, y);
    //        Cn.computeMagnetObjects();
    //        this.checkMagnets();
    //        Cn.computeAll();
    //        Cn.computeAll();
    //    };
    //
    //
    //    var dragToNormal = function(x, y) {
    //        this.dragObject(x, y);
    //        this.computeDrag(x,y);
    //        Cn.computeMagnetObjects();
    //        this.checkMagnets();
    //    };
    //
    //    this.dragTo = (Cn.is3D()) ? dragTo3D : dragToNormal;



}
